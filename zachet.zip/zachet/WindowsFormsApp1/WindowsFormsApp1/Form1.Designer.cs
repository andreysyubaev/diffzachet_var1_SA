﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.accept = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.sort = new System.Windows.Forms.ComboBox();
            this.delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // accept
            // 
            this.accept.Location = new System.Drawing.Point(12, 125);
            this.accept.Name = "accept";
            this.accept.Size = new System.Drawing.Size(460, 23);
            this.accept.TabIndex = 0;
            this.accept.Text = "Применить";
            this.accept.UseVisualStyleBackColor = true;
            this.accept.Click += new System.EventHandler(this.accept_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(0, 160);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(484, 251);
            this.listBox1.TabIndex = 1;
            // 
            // sort
            // 
            this.sort.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sort.FormattingEnabled = true;
            this.sort.ItemHeight = 13;
            this.sort.Items.AddRange(new object[] {
            "По возврастанию",
            "По убыванию"});
            this.sort.Location = new System.Drawing.Point(103, 64);
            this.sort.Name = "sort";
            this.sort.Size = new System.Drawing.Size(291, 21);
            this.sort.TabIndex = 2;
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(12, 426);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(460, 23);
            this.delete.TabIndex = 3;
            this.delete.Text = "Удалить";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.sort);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.accept);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button accept;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ComboBox sort;
        private System.Windows.Forms.Button delete;
    }
}

