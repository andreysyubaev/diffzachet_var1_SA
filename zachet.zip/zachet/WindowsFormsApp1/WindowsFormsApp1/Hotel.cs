﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Hotel
    {
        public string type { get; set; }
        public int countryId { get; set; }
        public string hotelName { get; set; }
        public double price { get; set; }
    }
}
