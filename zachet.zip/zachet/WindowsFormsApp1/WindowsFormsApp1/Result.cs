﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Result
    {
        public int id { get; set; }
        public string countryName { get; set; }
        public string hotelName { get; set; }
        public int count { get; set; }
        public double totalPrice { get; set; }
    }
}
