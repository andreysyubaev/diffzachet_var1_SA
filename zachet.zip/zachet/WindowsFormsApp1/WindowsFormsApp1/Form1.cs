﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void accept_Click(object sender, EventArgs e)
        {
            if (sort.SelectedIndex == 0) 
            {
                listBox1.Items.Clear();
                Data();

            }
            else if (sort.SelectedIndex == 1)
            {
                listBox1.Items.Clear();
                Data();

            }
            else
            {
                MessageBox.Show("выберите сортировку");
            }
        }

        private void Data()
        {  
            /*
            var countries = LoadCountries("countries.txt");
            var hotels = LoadCountries("hotels.txt");
            */
            

            var countries = new List<Country>
            {
                new Country { id = 1, name = "Турция" },
                new Country { id = 2, name = "Египет" }
            };

            var hotels = new List<Hotel>
            {
                new Hotel { type = "2", countryId = 1, hotelName = "Rivas", price = 2000},
                new Hotel { type = "1", countryId = 2, hotelName = "Sonesta", price = 1600}
            };
            

            var accept = from hotel in hotels
                         join country in countries on hotel.countryId equals country.id
                         orderby hotel.price
                         select new Result
                         {
                             id = country.id,
                             countryName = country.name,
                             hotelName = hotel.hotelName,
                             count = int.Parse(hotel.type),
                             totalPrice = hotel.price * int.Parse(hotel.type)
                         };

            string title1 = "ID\tНазвание отеля\tСтрана\tКоличество\tЦена";
            string title2 = "-------------------------------------------------------------------------------------------------------------------";
            listBox1.Items.Add(title1);
            listBox1.Items.Add(title2);

            foreach (var i in accept)
            {
                listBox1.Items.Add($"{i.id}\t{i.hotelName}\t\t{i.countryName}\t{i.count}\t\t{i.totalPrice}");
            }
        }

        private List<Country> LoadCountries(string file)
        {
            var countries = new List<Country>();
            foreach (var i in File.ReadAllLines(file))
            {
                var part = i.Split(',');
                countries.Add(new Country { id = int.Parse(part[0]), name = part[1] });
            }
            return countries;
        }

        private List<Hotel> LoadHotels(string file)
        {
            var hotels = new List<Hotel>();
            foreach (var i in File.ReadAllLines(file))
            {
                var part = i.Split(',');
                hotels.Add(new Hotel { type = part[0], countryId = int.Parse(part[1]), hotelName = part[2], price = double.Parse(part[3]) });
            }
            return hotels;
        }

        private void delete_Click(object sender, EventArgs e)
        {
            var currItems = listBox1.Items.Cast<string>().ToList();
            /*
            var newList = Removee(currItems, item => item.Contains("z"));

            listBox1.Items.Clear();

            foreach (var i in newList)
            {
                listBox1.Items.Add(i);
            }
            */
        }
        /*
        public static IEnumerable<Hotels> Removee(IEnumerable<Hotels> list, Func<Hotels, bool> c)
        {
            return list.Where(item => !c(item)).ToList();
        }
        */
    }
}
